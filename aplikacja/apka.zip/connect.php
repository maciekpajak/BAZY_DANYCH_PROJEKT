<?php
		$IP="localhost";
		$username="id13767441_dzienn";
		$password="bU#@]PEwH^DgS7cp";
		$DB_name="id13767441_dziennik";
?>