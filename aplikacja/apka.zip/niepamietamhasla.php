<?php
	session_start();
?>
<!DOCTYPE HTML>

<html lang="pl">
<head>
    
	<meta charset="utf-8" />
	<title>Dziennik elektroniczny</title>
	<meta name="description" content="opis w google"/>
	<meta name="keywords" content="słowa po których google szuka"/>

    <link rel="stylesheet" href="../Styles/styleLogin.css" type="text/css" />

	<meta http-equiv="X-UA_Compatible" content="IE=edge,chrome=1" />
	<meta name="author" content="Kowalski, Mielniczek, Pająk" />

</head>


<body>
	
	<div id="container">
	
		<div id="logo">
		
			<h1>Nie pamietasz hasła?</h1>
		
		</div>
		<div id="tresc">
		
		Skontaktu się z administracją.</br>
		<b>Email:</b> <a href="mailto:admin1@szkola.pl">admin1@szkola.pl</a></br>
		<b>Tel:</b> 111222333</br>
		
		</div>
		
		</form>


		<div id="footer">
		e-dziennik
		</div>

	</div>
	
</body>

</html>